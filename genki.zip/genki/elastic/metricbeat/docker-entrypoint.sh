#!/bin/bash
set -euo pipefail

timeout 90 bash -c "
  echo 'Waiting for Elasticsearch to be reachable.'
  until (echo >/dev/tcp/elasticsearch/9200) &>/dev/null; do sleep .1; done
  echo 'Waiting for Kibana to be reachable.'
  until (echo >/dev/tcp/kibana/5601) &>/dev/null; do sleep .1; done
  echo 'Waiting for Elasticsearch to be healthy.'
  until curl -s -X GET elasticsearch:9200/_cluster/health/\?wait_for_status\=yellow\&timeout\=60s | grep -q '\"status\":\"green\"'; do sleep .1; done"

echo "Setting up."

metricbeat setup \
  -E output.logstash.enabled=false \
  -E output.elasticsearch.hosts=['elasticsearch:9200']

echo "Starting up."

exec metricbeat "$@"
