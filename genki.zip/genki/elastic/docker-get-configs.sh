#!/bin/bash
DIRNAME="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)";

echo elastic-apm-server-config "$DIRNAME/apm-server/apm-server.yml"
echo elastic-caddyfile "$DIRNAME/caddy/Caddyfile"
echo elastic-curator-actions-config "$DIRNAME/curator/actions.yml"
echo elastic-curator-crontab "$DIRNAME/curator/crontab"
echo elastic-curator-curator-config "$DIRNAME/curator/curator.yml"
echo elastic-elasticsearch-config "$DIRNAME/elasticsearch/elasticsearch.yml"
echo elastic-filebeat-config "$DIRNAME/filebeat/filebeat.yml"
echo elastic-kibana-config "$DIRNAME/kibana/kibana.yml"
echo elastic-logstash-config "$DIRNAME/logstash/logstash.yml"
echo elastic-logstash-pipeline-filters "$DIRNAME/logstash/pipeline/filters.conf"
echo elastic-logstash-pipeline-inputs "$DIRNAME/logstash/pipeline/inputs.conf"
echo elastic-logstash-pipeline-outputs "$DIRNAME/logstash/pipeline/outputs.conf"
echo elastic-metricbeat-config "$DIRNAME/metricbeat/metricbeat.yml"
