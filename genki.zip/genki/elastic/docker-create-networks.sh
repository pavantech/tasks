#!/bin/bash
docker network create --attachable --driver overlay elastic
docker network create --attachable --driver overlay elastic-internal
docker network create --attachable --driver overlay kibana
docker network create --attachable --driver overlay telemetry
