// @flow
import delay from 'delay';
import Agent from 'elastic-apm-node';
import fastify from 'fastify';
import {PassThrough} from 'stream';

fastify({logger: true})
  .addHook('onRequest', ({url}, res, next) => {
    Agent.setTransactionName(url);
    next();
  })
  .setErrorHandler((error, request, reply) => {
    Agent.captureError(error);
    reply.send('We got an error!');
  })
  .get('/greet', async () => ({message: 'Greetings.'}))
  .get('/greet-slowly', async () => {
    await delay(1000);
    return {message: 'Greetings (slowly).'};
  })
  .post('/decrement', async ({body}) => ({count: body.count - 1}))
  .get('/error', async () => {
    throw new Error('Error!');
  })
  .get('/fatal', () => {
    new PassThrough().emit('error');
  })
  .listen(3000, '0.0.0.0');
