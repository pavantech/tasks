// @flow
import Agent from 'elastic-apm-node';
import fastify from 'fastify';
import got from 'got';
import {URL} from 'url';

const services = ['http://sample-one:3000', 'http://sample-two:3000'];

fastify({logger: true})
  .addHook('onRequest', ({url}, res, next) => {
    Agent.setTransactionName(url);
    next();
  })
  .setErrorHandler((error, request, reply) => {
    Agent.captureError(error);
    reply.send('We got an error!');
  })
  .post('/countdown', async ({body, log}) => {
    let {count} = body;
    while (count > 0) {
      const service = services[count % services.length];
      log.info({count, service}, 'Counting down!');
      ({
        body: {count},
        // eslint-disable-next-line no-await-in-loop
      } = await got.post(new URL('/decrement', service), {
        body: {count},
        json: true,
      }));
    }
    return 'Done!';
  })
  .listen(3000, '0.0.0.0');
