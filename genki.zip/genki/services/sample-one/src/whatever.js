const resolvers = {
  Query: {
    getWhatever() {
      return [{id: 1}, {id: 2}];
    },
  },
  Whatever: {
    name(whatever) {
      return whatever.id;
    },
  },
};
