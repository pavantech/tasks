// @flow
import delay from 'delay';
import Agent from 'elastic-apm-node';
import Koa from 'koa';
import bodyparser from 'koa-bodyparser';
import createRouter from 'koa-router';
import {PassThrough} from 'stream';

const koa = new Koa();
const router = createRouter()
  .get('/greet', async ctx => {
    ctx.body = {message: 'Greetings.'};
  })
  .get('/greet-slowly', async ctx => {
    await delay(1000);
    ctx.body = {message: 'Greetings (slowly).'};
  })
  .post('/decrement', async ctx => {
    ctx.body = {count: ctx.request.body.count - 1};
  })
  .get('/error', async () => {
    throw new Error('Error!');
  })
  .get('/fatal', () => {
    new PassThrough().emit('error');
  });

koa
  .use(bodyparser())
  .use(async (ctx, next) => {
    try {
      await next();
    } catch (error) {
      Agent.captureError(error);
      ctx.app.emit('error', error, ctx);
    }
  })
  .use(router.routes())
  .listen(3000);
