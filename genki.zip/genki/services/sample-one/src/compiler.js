function genError(err, line, column) {
  const ex = new Error(err);
  ex.line = line;
  ex.column = column;
  throw ex;
}

function quoteDottedString(string) {
  return string.includes('.') ? `"${string}"` : string;
}

function reduceArrayWithTypeChecking(nodes) {
  // Ensure that all items in the array are of the same type
  let firstType = null;
  for (const {column, line, type} of nodes) {
    if (firstType === null) {
      firstType = type;
    } else if (type !== firstType) {
      genError(
        `Cannot add value of type ${type} to array of type ${firstType}.`,
        line,
        column,
      );
    }
  }

  // Recursively reduce array of nodes into array of the nodes' values
  return nodes.map(node => reduceValueNode(node));
}

function reduceInlineTableNode(values) {
  const result = {};

  for (const {key, value} of values) {
    if (value.type === 'InlineTable') {
      result[key] = reduceInlineTableNode(value.value);
    } else if (value.type === 'InlineTableValue') {
      result[key] = reduceValueNode(value);
    }
  }

  return result;
}

function reduceValueNode(node) {
  if (node.type === 'Array') {
    return reduceArrayWithTypeChecking(node.value);
  }
  if (node.type === 'InlineTable') {
    return reduceInlineTableNode(node.value);
  }
  return node.value;
}

function compile(nodes) {
  let assignedPaths = [];
  const valueAssignments = new Set();
  let currentPath = '';
  const data = {};
  let context = data;

  function deepRef(keys, value, line, column) {
    const traversed = [];
    let traversedPath = '';

    context = data;
    keys.forEach((key, index) => {
      traversed.push(key);
      traversedPath = traversed.join('.');
      if (typeof context[key] === 'undefined') {
        context[key] = index === keys.length - 1 ? value : {};
      } else if (
        index !== keys.length - 1 &&
        valueAssignments.has(traversedPath)
      ) {
        // already a non-object value at key, can't be used as part of a new path
        genError(
          `Cannot redefine existing key '${traversedPath}'.`,
          line,
          column,
        );
      }

      context = context[key];
      if (Array.isArray(context) && context.length && index < keys.length - 1) {
        context = context[context.length - 1];
      }
    });
  }

  function addTableArray(node) {
    const {column, line, value} = node;
    const quotedPath = value.map(quoteDottedString).join('.');

    assignedPaths = assignedPaths.filter(path => !path.startsWith(quotedPath));
    assignedPaths.push(quotedPath);
    deepRef(value, [], line, column);
    currentPath = quotedPath;

    if (Array.isArray(context)) {
      const newObj = {};
      context.push(newObj);
      context = newObj;
    } else {
      genError(`Cannot redefine existing key '${value}'.`, line, column);
    }
  }

  function assign(node) {
    const {column, key, line, value} = node;
    const fullPath = currentPath ? `${currentPath}.${key}` : key;
    if (typeof context[key] !== 'undefined') {
      genError(`Cannot redefine existing key '${fullPath}'.`, line, column);
    }

    context[key] = reduceValueNode(value);

    if (!assignedPaths.includes(fullPath)) {
      assignedPaths.push(fullPath);
      valueAssignments.add(fullPath);
    }
  }

  function setPath(node) {
    const {column, line, value} = node;
    const quotedPath = value.map(quoteDottedString).join('.');

    if (assignedPaths.includes(quotedPath)) {
      genError(`Cannot redefine existing key '${value}'.`, line, column);
    }
    assignedPaths.push(quotedPath);
    deepRef(value, {}, line, column);
    currentPath = value;
  }

  for (const node of nodes) {
    switch (node.type) {
      case 'Assign':
        assign(node);
        break;
      case 'ObjectPath':
        setPath(node);
        break;
      case 'ArrayPath':
        addTableArray(node);
        break;
      default:
        break;
    }
  }

  return data;
}

module.exports = {
  compile,
};
