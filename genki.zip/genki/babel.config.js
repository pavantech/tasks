module.exports = {
  babelrcRoots: 'services/*',
};
